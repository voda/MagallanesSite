<?php

namespace Mage\Config;

use Mage\Yaml\Exception\RuntimeException;

/**
 *
 * @author Vladimir Grigor <vgrigor@gmail.com>
 */
class RequiredConfigNotFoundException extends RuntimeException
{
}
